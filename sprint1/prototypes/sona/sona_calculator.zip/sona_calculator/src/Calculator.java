import java.util.Scanner;

/**
 * Simple calculator app that performs basic arithmetic on two numbers
 * author: Sona Hariharan (33221898)
 */
public class Calculator {

  public static void main(String[] args) {
    // attributes
    double x = 0;
    double y = 0;
    double result = 0;
    char op;
    char reply; //determines whether program terminates

    // create scanner object for user input
    Scanner scanner = new Scanner(System.in);
    System.out.println("-----Calculator-----");

    while (true) {
      // request first number
      System.out.println("Please enter the first number: ");
      while (!scanner.hasNextDouble()) {
        //invalid input
        System.out.println("Please enter a valid number.");
        scanner.next();
      }
      x = scanner.nextDouble(); //valid number entered

      // request second number
      System.out.println("Please enter the second number: ");
      while (!scanner.hasNextDouble()) {
        //invalid input
        System.out.println("Please enter a valid number.");
        scanner.next();
      }
      y = scanner.nextDouble(); //valid number entered

      // request valid operator input
      System.out.println("Select operator: +, -, *, / ");
      while (true) {
        op = scanner.next().charAt(0);
        if (op == '+' || op == '-' || op == '*' || op == '/') {
          break; //valid operator entered
        } else { //invalid operator
          System.out.println("Please select a valid operator.");
        }
      }
      // perform appropriate operation
      switch (op) {
        // addition +
        case '+':
          result = x + y;
          break;

        // subtraction -
        case '-':
          result = x - y;
          break;

        // multiplication *
        case '*':
          result = x * y;
          break;

        // division /
        case '/':
          if (y != 0) { //check for 0 division
            result = x / y;
          } else {
            System.out.println("Invalid operation, division by zero is not supported.");
          }
          break;
      }

      // print result to user
      System.out.printf("Result: %.2f %c %.2f = %.2f\n", x, op, y, result);
      System.out.println("Would you like to perform another calculation? (y/n)");
      reply = scanner.next().charAt(0);
      if (reply != 'y' && reply != 'Y') {
        System.out.println("Exiting...bye!");
        break;
      }
    }
    scanner.close();
  }
}