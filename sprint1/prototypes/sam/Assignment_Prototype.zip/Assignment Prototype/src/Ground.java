public class Ground extends Piece {

}
