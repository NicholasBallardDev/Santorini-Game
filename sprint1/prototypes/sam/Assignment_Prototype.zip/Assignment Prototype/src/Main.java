import java.io.File;
import java.io.FileFilter;
import java.util.Scanner;

public class Main {

    private static String[] load_files_from_directory(String directory_name, String file_type){
        try{
            File directory = new File(directory_name);
            FileFilter filter = new FileFilter() {
                public boolean accept(File f){
                    return f.getName().endsWith("." + file_type);
                }
            };
            File[] maps_list = directory.listFiles(filter);
            assert maps_list != null;
            String[] output = new String[maps_list.length];
            for(int i = 0; i < maps_list.length; i++){
                output[i] = maps_list[i].getName();
            }
            return output;
        } catch (Exception FileNotFoundException){
            System.out.println("\nCreate map directory\n");
        }
        return new String[]{};
    }

    private static String generate_choose_from_directory(String directory_name, String file_type){
        String[] option_list = load_files_from_directory(directory_name, file_type);
        if (option_list.length == 0){
            System.out.println("Please put at least (1) " + file_type + " in the folder " + directory_name);
            return "";
        }
        for(int i = 0; i < option_list.length; i++){
            String map_name = option_list[i];
            String[] slice = map_name.split("[/.]");
            int num = i + 1;
            System.out.println("\t" + num + ". " + slice[0]);
        }
        int num = option_list.length+1;
        System.out.println("\t" + num + ". Back To Menu\n");
        Scanner read = new Scanner(System.in);
        while(true){
            int selection = read.nextInt()-1;
            if((option_list.length > selection) && (selection >= 0)){
                return option_list[selection];
            } else if(selection == option_list.length) {
                return "";
            } else {
                System.out.println("Invalid Selection. Please try again\n");
            }
        }
    }

    private static void new_game(){
        Scanner read = new Scanner(System.in);
        System.out.println("\nSelect number of players: ");
        int number_of_players = read.nextInt();
        System.out.println("\nSelect map to play on: ");
        String map = generate_choose_from_directory("Maps", "map");
        if(map.isEmpty()) return;
        System.out.println("\nGame Started: ");
        //Board board = new Board(map_list[map_selection]);
        //Game game = new Game(board, number_of_players);
        //game.start_game();
    }

    private static void load_game(){
        System.out.println("\nSelect save file to load: ");
        String save_file = generate_choose_from_directory("SaveFiles", "save");
        if(save_file.isEmpty()) return;
        System.out.println("\nGame Started: ");
    }

    private static void settings(){
        Scanner read = new Scanner(System.in);
        while(true){
            System.out.println("Select an Setting To Change:\n\t1. Exit Settings.json");
            int input = read.nextInt();
            switch(input) {
                case 1:
                    return;
                default:
                    System.out.println("Invalid Selection. \n");
            }
        }
    }

    private static void main_menu(){
        System.out.println("Santorini Main Menu:");
        Scanner read = new Scanner(System.in);
        while(true){
            System.out.println("\nSelect an Option:\n\t1. New Game\n\t2. Load Game\n\t3. Settings.json\n\t4. Quit Game\n");
            int input = read.nextInt();
            switch(input){
                case 1:
                    new_game();
                    break;
                case 2:
                    load_game();
                    break;
                case 3:
                    settings();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid Selection. Please input a single number presented.");
            }
        }
    }

    public static void main(String[] args) {
        main_menu();
    }
}