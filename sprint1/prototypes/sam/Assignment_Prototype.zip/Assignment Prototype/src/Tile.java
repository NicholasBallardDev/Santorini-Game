public class Tile {
    boolean perimeter = false;
    boolean traversable = false;
    Piece[] stack;

    public Tile(){
        stack = new Piece[10];
    }

    public void setPerimeter(){
        perimeter = true;
    }
    public void setTraversable(){
        traversable = true;
    }

    public Tile(char type){
        if(type != 'x'){
            setTraversable();
            if(Character.isDigit(type)){
                int digit = (int) type;
                assert(5>digit && digit >= 0);
                for(int i = 0; i < digit; i++){
                    stack[i] = new Ground();
                }
            }
        }
    }
}
