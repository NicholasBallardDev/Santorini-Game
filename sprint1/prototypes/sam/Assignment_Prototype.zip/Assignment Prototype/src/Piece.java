public class Piece {
}
