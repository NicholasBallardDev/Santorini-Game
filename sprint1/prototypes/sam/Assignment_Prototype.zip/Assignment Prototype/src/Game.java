public class Game {
    Board board;


    public Game(Board new_board, int number_of_players){
        board = new_board;
    }

    private void set_up_game(){

    }

    public void start_game(){
        set_up_game();
        return;
    }
}
