import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Board {
    Tile[][] tile_array;

    public void generate_array(String file_name){
        try {
            File map_file = new File(file_name);
            Scanner read_file = new Scanner(map_file);
            String[] dims_strings = read_file.nextLine().split("[ ]");
            int[] dims = {Integer.parseInt(dims_strings[0]), Integer.parseInt(dims_strings[1])};
            tile_array = new Tile[dims[0]][];
            for(int i = 0; i < dims[0]; i++) {
                String line = read_file.nextLine();
                tile_array[i] = new Tile[dims[1]];
                for (int j = 0; j < dims[1]; j++) {
                    char character = line.charAt(j);
                    tile_array[i][j] = new Tile(character);
                }
            }
        } catch (Exception FileNotFoundException) {
            System.out.println("\nInvalid Map File Name " + file_name + "\n");
        }
    }

    public void set_perimeter(){
        
    }

    public Board(String file_name) {
        generate_array(file_name);
    }
}
